/*
⌬
┇ ━━━[ 🥳 𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗕𝗥𝗢𝗞 ]━━━━
┇
┇ ❘█▀█ █ █▀█ █▀█   ▄▀█ █
┇ █  █ █ █▀▄ █▄█   █▀█ █    
┇  ▀█  --N--a--n--o------A--i-----
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ 💬 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ]━━━━
┇
┇▫️Author  : Danz nano & Awang Ofc 
┇▫️Website  : awangofc.my.id
┇▫️WhatsApp : wa.me/556184127506
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ ✍️ 𝗖𝗔𝗧𝗔𝗧𝗔𝗡 ]━━━━
┇
┇🔸Dilarang Menghapus Creadit SC
┇🔸Dilarang Menjual Script Nano Ai
┇🔸Dilarang Mengatas Namakan Script!!
⌬
*/


import {
  default as makeWASocket,
  DisconnectReason,
  fetchLatestBaileysVersion,
  Browsers,
  makeCacheableSignalKeyStore,
} from '@whiskeysockets/baileys'
import { Boom } from '@hapi/boom'
import pino from 'pino'
import { settings } from '../config/settings.js'
import {
  ensureSessionDir,
  clearSession,
  useSQLiteAuthState,
} from './sesi.js'
import { printStatus } from '../tampilan/banner.js'

// set NANO_LOG=trace untuk merekam seluruh lalu-lintas node XML ke server WhatsApp
const logger = pino({ level: process.env.NANO_LOG || 'silent' })

let pairingRequested = false
let pairingCodeShown = false

async function resolvePairingNumber() {
  if (process.env.PAIRING_NUMBER) {
    return process.env.PAIRING_NUMBER.replace(/\D/g, '')
  }

  if (settings.pairingNumber) {
    return settings.pairingNumber.replace(/\D/g, '')
  }

  if (process.stdin.isTTY) {
    const readlineSync = (await import('readline-sync')).default
    const chalk = (await import('chalk')).default
    console.log('')
console.log(chalk.cyan('╭────────────────────╮'))
    console.log(chalk.cyan('│') + chalk.bold.white('  📱 PAIRING NUMBER  ') + chalk.cyan('│'))
    console.log(chalk.cyan('├────────────────────┤'))
    console.log(chalk.cyan('│') + chalk.gray('  Masukkan nomor bot  ') + chalk.cyan('│'))
    console.log(chalk.cyan('│') + chalk.gray('  Format: ') + chalk.white('6281234567890') + chalk.cyan('  │'))
    console.log(chalk.cyan('╰────────────────────╯'))
    const input = readlineSync.question(chalk.cyan('  › '))
    return input.replace(/\D/g, '')
  }

  return null
}

export async function startConnection({ onReady, onPluginReload } = {}) {
  await ensureSessionDir()

  const { state, saveCreds } = await useSQLiteAuthState()
  const { version } = await fetchLatestBaileysVersion()

  const conn = makeWASocket({
    version,
    logger,
    printQRInTerminal: false,
    qrTimeout: 60000, // masa hidup tiap QR (bawaan fork: 60s pertama, 20s berikutnya)
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    browser: Browsers.ubuntu('Chrome'),
    generateHighQualityLinkPreview: true,
    syncFullHistory: false,
    markOnlineOnConnect: true,
  })

  const usingPairing = !state.creds?.registered

  conn.ev.on('creds.update', saveCreds)

  const requestPairingCodeWithRetry = async (number) => {
    let code
    let lastError
    const maxAttempts = 3

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        code = await conn.requestPairingCode(number)
        break
      } catch (attemptErr) {
        lastError = attemptErr
        if (attempt < maxAttempts) {
          printStatus(
            `Percobaan ${attempt} gagal (${attemptErr.message}), mencoba lagi...`,
            'warn'
          )
          await new Promise((resolve) => setTimeout(resolve, 2000))
        }
      }
    }

    if (!code) throw lastError
    return code
  }

  conn.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update

    // Mode QR opsional (set NANO_QR=1): QR dicetak sebagai URL gambar siap-scan,
    // berguna di panel/headless yang tidak bisa menampilkan QR di terminal.
    if (qr && process.env.NANO_QR) {
      console.log('QR_IMAGE=https://api.qrserver.com/v1/create-qr-code/?size=800x800&margin=10&data=' + encodeURIComponent(qr))
    }

    const readyForPairing = usingPairing && !state.creds?.registered && !process.env.NANO_QR && (qr || connection === 'connecting')

    if (readyForPairing && !pairingRequested) {
      pairingRequested = true

      setTimeout(async () => {
        const number = await resolvePairingNumber()

        if (!number) {
          printStatus(
            'Nomor pairing tidak ditemukan. Isi PAIRING_NUMBER (env) atau settings.pairingNumber di config/settings.js',
            'error'
          )
          process.exit(1)
        }

        try {
          printStatus(`Meminta kode untuk nomor tujuan : ${number}`, 'loading')

          const code = await requestPairingCodeWithRetry(number)
          pairingCodeShown = true

          const formattedCode = code?.match(/.{1,4}/g)?.join('-') || code
          console.log('')
console.log('  \x1b[36m╭────────────────────╮\x1b[0m')
          console.log('  \x1b[36m│\x1b[0m  \x1b[1m\x1b[37m🔐 PAIRING CODE\x1b[0m  \x1b[36m│\x1b[0m')
          console.log('  \x1b[36m├────────────────────┤\x1b[0m')
          console.log(`  \x1b[36m│\x1b[0m      \x1b[1m\x1b[32m${String(formattedCode)}\x1b[0m      \x1b[36m│\x1b[0m`)
          console.log('  \x1b[36m╰────────────────────╯\x1b[0m')
          console.log('')
          printStatus('WhatsApp > Perangkat Tertaut > Tautkan Perangkat', 'info')
          printStatus('Pilih "Tautkan dengan nomor telepon", lalu masukkan kode di atas.', 'info')
          printStatus('Kode berlaku sekitar 60 detik. Restart bot jika kode kedaluwarsa.', 'warn')
        } catch (err) {
          printStatus(`Gagal meminta pairing code: ${err.message}`, 'error')
          printStatus('Pastikan nomor benar dan koneksi internet stabil, lalu restart bot.', 'warn')
        }
      }, 3000)
    }

    if (connection === 'open') {
      pairingRequested = false
      printStatus('Berhasil terhubung ke WhatsApp!', 'success')
      onReady?.(conn)
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut

      if (statusCode === DisconnectReason.loggedOut) {
        printStatus('Sesi logout dari perangkat. Menghapus sesi lama...', 'warn')
        try {
          clearSession()
        } catch (err) {
          printStatus(`Gagal menghapus sesi lama: ${err.message}`, 'error')
        }
        pairingRequested = false
        pairingCodeShown = false
      }

      if (shouldReconnect) {
        printStatus('Koneksi terputus, mencoba menyambung ulang...', 'warn')
        setTimeout(() => startConnection({ onReady, onPluginReload }), 3000)
      } else {
        printStatus('Bot berhenti (logged out). Jalankan ulang untuk pairing baru.', 'error')
        process.exit(0)
      }
    }
  })

  return conn
}

export default { startConnection }
