/*
⌬
┇ ━━━[ 🥳 𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗕𝗥𝗢𝗞 ]━━━━
┇
┇ ❘█▀█ █ █▀█ █▀█   ▄▀█ █
┇ █  █ █ █▀▄ █▄█   █▀█ █    
┇  ▀█  --N--a--n--o------A--i-----
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ 💬 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ]━━━━
┇
┇▫️Author  : Danz nano & Awang Ofc 
┇▫️Website  : awangofc.my.id
┇▫️WhatsApp : wa.me/556184127506
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ ✍️ 𝗖𝗔𝗧𝗔𝗧𝗔𝗡 ]━━━━
┇
┇🔸Dilarang Menghapus Creadit SC
┇🔸Dilarang Menjual Script Nano Ai
┇🔸Dilarang Mengatas Namakan Script!!
⌬
*/

'use strict'

const html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Nano Ai Tic Tac Toe</title>
<style>
:root{--bg:#151816;--bg2:#1b1e1a;--panel:#232722;--panel2:#292e28;--panel3:#30362f;--line:#414840;--ink:#e1e2d9;--muted:#969e95;--olive:#a7b59f;--olive2:#3f4b41;--bronze:#8e7757;--bronze2:#5b4c3a;--board:#514432;--cell:#d0c4a8;--cell2:#bdb091;--x:#718b7b;--o:#b77d69;--gold:#b79b61;--shadow:#0b0d0c}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;min-height:100%;background:radial-gradient(circle at 50% -20%,#2a3029 0,#1c201d 34%,#141715 72%);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}
body{padding:10px}.app{width:min(100%,560px);margin:auto}
.header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:9px}.brand{display:flex;align-items:center;gap:10px;min-width:0}.mark{width:44px;height:44px;flex:0 0 auto;border-radius:13px;display:grid;place-items:center;background:linear-gradient(145deg,#343a33,#222720);border:1px solid #454c44;box-shadow:6px 6px 12px var(--shadow),-3px -3px 8px #33392f;color:#ddd9cb;font:500 21px/1 Georgia,"Times New Roman",serif}.title{font-size:20px;font-weight:900;letter-spacing:-.35px}.sub{margin-top:2px;color:var(--muted);font-size:9.5px;line-height:1.35}.status{padding:7px 9px;border-radius:11px;border:1px solid var(--line);background:linear-gradient(145deg,#2c322c,#20251f);box-shadow:4px 4px 8px var(--shadow),-2px -2px 6px #30352e;font-size:9px;font-weight:900;white-space:nowrap}
.topControls{display:grid;grid-template-columns:minmax(0,1fr) minmax(145px,.72fr);gap:7px;margin-bottom:8px}.select,.btn{width:100%;min-height:42px;border:1px solid var(--line);border-radius:12px;background:linear-gradient(145deg,#2b302a,#20241f);color:var(--ink);font:800 10.5px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;outline:0;box-shadow:4px 4px 8px var(--shadow),-2px -2px 6px #30352e}.select{padding:0 10px}.btn{padding:0 10px;cursor:pointer;touch-action:manipulation}.btn:active{transform:translateY(1px);box-shadow:inset 2px 2px 5px #121512,inset -2px -2px 4px #343a32}.btn.primary{background:linear-gradient(145deg,#3b4840,#2a322c);border-color:#56655b;color:#e4eadf}.btn.olive{background:linear-gradient(145deg,#344039,#273129);border-color:#4a5b50}.btn.warm{background:linear-gradient(145deg,#4a3c31,#352c25);border-color:#635145}
.game{padding:10px;border:1px solid #394038;border-radius:18px;background:linear-gradient(145deg,rgba(43,48,42,.97),rgba(31,35,30,.98));box-shadow:9px 10px 22px var(--shadow),-4px -4px 10px #2b302a}
.roundLine{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 2px 8px}.round{display:flex;align-items:center;gap:7px;text-transform:uppercase;letter-spacing:.7px;font-size:9px;font-weight:950}.dot{width:8px;height:8px;border-radius:50%;background:var(--olive);box-shadow:0 0 0 4px #354137}.turn{font-size:9px;color:var(--muted);text-align:right}
.boardFrame{width:min(100%,470px);margin:auto;padding:9px;border:1px solid #79674e;border-radius:18px;background:linear-gradient(145deg,#68563f,#463a2d);box-shadow:inset 2px 2px 4px #7b694f,inset -3px -3px 6px #362d22,8px 10px 18px #11140f}.board{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;padding:7px;width:100%;aspect-ratio:1;border-radius:13px;background:linear-gradient(145deg,#4d3f30,#5b4937);box-shadow:inset 3px 3px 7px #33291f,inset -2px -2px 5px #6a5641}.cell{position:relative;display:grid;place-items:center;min-width:0;border:1px solid #94876f;border-radius:11px;background:linear-gradient(145deg,var(--cell),var(--cell2));box-shadow:4px 4px 7px #392f26,-2px -2px 5px #79674f;cursor:pointer;touch-action:manipulation;transition:transform .1s ease,filter .1s ease,box-shadow .1s ease}.cell:active{transform:translateY(1px);box-shadow:2px 2px 4px #392f26,-1px -1px 3px #79674f}.cell.locked{cursor:default}.cell.empty .symbol{opacity:0}.cell.x{color:var(--x)}.cell.o{color:var(--o)}.symbol{font:500 clamp(39px,13vw,72px)/.9 Georgia,"Times New Roman",serif;text-shadow:0 1px 0 #eee5d2,0 2px 2px #8f836c}.cell.win{filter:saturate(1.08);box-shadow:inset 0 0 0 2px var(--gold),4px 4px 7px #392f26,-2px -2px 5px #79674f}.cell.hint{box-shadow:inset 0 0 0 2px var(--olive),4px 4px 7px #392f26,-2px -2px 5px #79674f}.cell[data-num]:before{content:attr(data-num);position:absolute;top:5px;left:6px;color:#756b59;font:800 7px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;opacity:.75}
.score{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:8px}.stat{min-width:0;padding:8px 5px;border:1px solid var(--line);border-radius:12px;background:linear-gradient(145deg,#2e342e,#222722);box-shadow:3px 3px 7px var(--shadow),-2px -2px 5px #31372f;text-align:center}.stat b{display:block;font-size:15px;line-height:1.05}.stat span{display:block;margin-top:3px;color:var(--muted);font-size:7px;text-transform:uppercase;letter-spacing:.55px}
.turnBar{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:8px}.player{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;border-radius:12px;border:1px solid var(--line);background:linear-gradient(145deg,#2d332d,#232823);box-shadow:3px 3px 7px var(--shadow),-2px -2px 5px #31372f}.player.active{border-color:#5b6d60;box-shadow:inset 0 0 0 1px #536358,3px 3px 7px var(--shadow),-2px -2px 5px #31372f}.pname{font-size:9.5px;font-weight:900}.psub{margin-top:3px;color:var(--muted);font-size:7.8px}.badge{width:27px;height:27px;border-radius:9px;display:grid;place-items:center;font:900 11px/1 Georgia,"Times New Roman",serif;box-shadow:inset 1px 1px 2px #3b4039,inset -1px -1px 2px #171a16}.badge.x{background:#3e5146;color:#dce8de}.badge.o{background:#5a4139;color:#f1ddd5}
details.tools{margin-top:8px;border:1px solid var(--line);border-radius:12px;background:linear-gradient(145deg,#2c312c,#222721);box-shadow:3px 3px 7px var(--shadow),-2px -2px 5px #31372f;overflow:hidden}details.tools summary{list-style:none;cursor:pointer;padding:10px 11px;font-size:9px;font-weight:900;user-select:none}details.tools summary::-webkit-details-marker{display:none}.toolBody{padding:0 9px 9px;display:grid;grid-template-columns:repeat(2,1fr);gap:7px}.toolBody .btn{min-height:39px;font-size:9px;box-shadow:3px 3px 6px var(--shadow),-2px -2px 4px #30362f}.note{margin-top:8px;padding:8px 9px;border:1px solid #3e453d;border-radius:11px;background:#20251f;color:#929a92;text-align:center;font-size:8px;line-height:1.4}
.overlay{position:fixed;inset:0;z-index:30;display:none;align-items:center;justify-content:center;padding:15px;background:rgba(9,11,9,.78)}.overlay.show{display:flex}.modal{width:min(92vw,400px);padding:18px;border:1px solid #4a5149;border-radius:18px;background:linear-gradient(145deg,#30362f,#20251f);box-shadow:10px 12px 25px #080908,-5px -5px 12px #343a32;text-align:center}.modalIcon{width:58px;height:58px;margin:0 auto 8px;border-radius:17px;display:grid;place-items:center;background:linear-gradient(145deg,#3d463d,#283028);border:1px solid #4c574e;box-shadow:6px 6px 11px var(--shadow),-3px -3px 8px #3a4038;font:500 34px/1 Georgia,"Times New Roman",serif}.modal h2{margin:3px 0;font-size:22px}.modal p{margin:7px 0 13px;color:var(--muted);font-size:9.5px;line-height:1.45}.result{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:11px}.result div{padding:8px;border:1px solid var(--line);border-radius:11px;background:linear-gradient(145deg,#2e342e,#222722)}.result b{display:block;font-size:15px}.result span{font-size:7.5px;color:var(--muted);text-transform:uppercase}.modalBtns{display:grid;grid-template-columns:1fr 1fr;gap:7px}.toast{position:fixed;left:50%;bottom:76px;z-index:40;max-width:88vw;padding:8px 10px;border:1px solid #4a5249;border-radius:10px;background:#282e28;color:#e4e5de;font-size:8.5px;font-weight:900;box-shadow:6px 7px 12px #090b09,-3px -3px 7px #353b34;transform:translate(-50%,10px);opacity:0;pointer-events:none;transition:opacity .12s ease,transform .12s ease}.toast.show{opacity:1;transform:translate(-50%,0)}
@media(max-width:420px){body{padding:7px}.header{gap:8px}.mark{width:41px;height:41px}.title{font-size:18px}.sub{font-size:8.7px}.status{font-size:8px;padding:7px 8px}.game{padding:8px;border-radius:16px}.boardFrame{padding:8px;border-radius:16px}.board{gap:6px;padding:6px}.cell{border-radius:10px}.score,.turnBar,.toolBody{gap:6px}.stat{padding:7px 4px}.stat span{font-size:6.6px}.player{padding:8px 9px}.pname{font-size:9px}.psub{font-size:7.2px}}
@media(max-width:340px){.topControls{grid-template-columns:1fr}.status{display:none}.score{grid-template-columns:1fr 1fr}.turnBar{grid-template-columns:1fr}.toolBody{grid-template-columns:1fr}.title{font-size:17px}}
@media(prefers-reduced-motion:reduce){*{transition:none!important}}
</style>
</head>
<body>
<div class="app">
<div class="header"><div class="brand"><div class="mark">✕○</div><div><div class="title">Tic Tac Toe</div><div class="sub">Ruang kecil, papan tegas, langkah tanpa ramai.</div></div></div><div class="status" id="status">Giliran X</div></div>
<div class="topControls"><select id="mode" class="select" aria-label="Mode permainan"><option value="easy">Santai · Nano mudah</option><option value="normal" selected>Seimbang · Nano normal</option><option value="hard">Tajam · Nano sulit</option><option value="pvp">2 Pemain · Lokal</option></select><button id="newGame" class="btn primary" type="button">＋ Permainan Baru</button></div>
<div class="game">
<div class="roundLine"><div class="round"><span class="dot"></span><span id="roundText">Ronde 1</span></div><div class="turn" id="turnText">X sedang bermain</div></div>
<div class="boardFrame"><div id="board" class="board" aria-label="Papan Tic Tac Toe"></div></div>
<div class="score"><div class="stat"><b id="scoreX">0</b><span>X Menang</span></div><div class="stat"><b id="scoreO">0</b><span>O Menang</span></div><div class="stat"><b id="scoreD">0</b><span>Seri</span></div><div class="stat"><b id="moves">0</b><span>Langkah</span></div></div>
<div class="turnBar"><div class="player active" id="playerX"><div><div class="pname" id="nameX">Kamu</div><div class="psub" id="subX">Giliran aktif</div></div><div class="badge x">X</div></div><div class="player" id="playerO"><div><div class="pname" id="nameO">Nano</div><div class="psub" id="subO">Menunggu</div></div><div class="badge o">O</div></div></div>
<details class="tools"><summary>Pengaturan & alat</summary><div class="toolBody"><button id="undo" class="btn olive" type="button">↶ Urungkan</button><button id="swap" class="btn" type="button">⇄ Tukar Sisi</button><button id="hint" class="btn" type="button">◌ Petunjuk</button><button id="sound" class="btn warm" type="button">♪ Suara: Mati</button><button id="resetScore" class="btn" type="button">↻ Reset Skor</button></div></details>
<div class="note" id="note">Tap kotak kosong untuk bermain. 1–9 dari keyboard juga bisa dipakai.</div>
</div>
</div>
<div id="overlay" class="overlay" role="dialog" aria-modal="true" aria-labelledby="resultTitle"><div class="modal"><div class="modalIcon" id="resultIcon">✕</div><h2 id="resultTitle">Selesai</h2><p id="resultText">Ronde selesai.</p><div class="result"><div><b id="resultX">0</b><span>X</span></div><div><b id="resultO">0</b><span>O</span></div><div><b id="resultDraw">0</b><span>Seri</span></div></div><div class="modalBtns"><button id="playAgain" class="btn primary" type="button">Main Lagi</button><button id="closeModal" class="btn" type="button">Tutup</button></div></div></div>
<div id="toast" class="toast" aria-live="polite"></div>
<script>
const $=id=>document.getElementById(id);const boardEl=$('board'),modeEl=$('mode'),statusEl=$('status'),roundText=$('roundText'),turnText=$('turnText'),scoreXEl=$('scoreX'),scoreOEl=$('scoreO'),scoreDEl=$('scoreD'),movesEl=$('moves'),nameXEl=$('nameX'),nameOEl=$('nameO'),subXEl=$('subX'),subOEl=$('subO'),playerXEl=$('playerX'),playerOEl=$('playerO'),noteEl=$('note'),overlay=$('overlay'),resultIcon=$('resultIcon'),resultTitle=$('resultTitle'),resultText=$('resultText'),resultX=$('resultX'),resultO=$('resultO'),resultDraw=$('resultDraw'),toast=$('toast');
const WIN_LINES=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];const SCORE_KEY='nano-ttt-score-v2',SETTINGS_KEY='nano-ttt-settings-v2';let board=Array(9).fill(''),turn='X',human='X',ai='O',mode='normal',round=0,history=[],gameOver=false,busy=false,winningLine=[],hintCell=-1,soundOn=false,audioCtx=null,score={X:0,O:0,D:0},gameToken=0,aiTimer=null;
function loadState(){try{const saved=JSON.parse(localStorage.getItem(SCORE_KEY)||'null');if(saved&&Number.isFinite(saved.X)&&Number.isFinite(saved.O)&&Number.isFinite(saved.D))score={X:Math.max(0,saved.X),O:Math.max(0,saved.O),D:Math.max(0,saved.D)};const cfg=JSON.parse(localStorage.getItem(SETTINGS_KEY)||'null');if(cfg&&['easy','normal','hard','pvp'].includes(cfg.mode))mode=cfg.mode;if(cfg&&['X','O'].includes(cfg.human))human=cfg.human;soundOn=Boolean(cfg&&cfg.soundOn)}catch{score={X:0,O:0,D:0}}
}
function saveState(){try{localStorage.setItem(SCORE_KEY,JSON.stringify(score));localStorage.setItem(SETTINGS_KEY,JSON.stringify({mode,human,soundOn}))}catch{}}
function opponent(p){return p==='X'?'O':'X'}function emptyCells(b){const out=[];for(let i=0;i<9;i++)if(!b[i])out.push(i);return out}
function checkResult(b){for(const line of WIN_LINES){const[a,c,d]=line;if(b[a]&&b[a]===b[c]&&b[a]===b[d])return{winner:b[a],line}}return emptyCells(b).length?null:{winner:'D',line:[]}}
function lineFor(b,p){for(const line of WIN_LINES){const[a,c,d]=line;const vals=[b[a],b[c],b[d]];if(vals.filter(v=>v===p).length===2&&vals.filter(v=>v==='').length===1)return line.find(i=>!b[i])}return-1}
function winningMove(b,p){return lineFor(b,p)}function centerOrCorner(b){if(!b[4])return 4;const corners=[0,2,6,8].filter(i=>!b[i]);if(corners.length)return corners[Math.floor(Math.random()*corners.length)];return emptyCells(b)[0]??-1}
function minimax(b,player,depth,alpha,beta){const result=checkResult(b);if(result){if(result.winner===ai)return 10-depth;if(result.winner===human)return depth-10;return 0}const moves=emptyCells(b);if(!moves.length)return 0;if(player===ai){let best=-Infinity;for(const move of moves){b[move]=ai;best=Math.max(best,minimax(b,human,depth+1,alpha,beta));b[move]='';alpha=Math.max(alpha,best);if(beta<=alpha)break}return best}let best=Infinity;for(const move of moves){b[move]=human;best=Math.min(best,minimax(b,ai,depth+1,alpha,beta));b[move]='';beta=Math.min(beta,best);if(beta<=alpha)break}return best}
function bestMove(b){const moves=emptyCells(b);if(!moves.length)return-1;let bestScore=-Infinity,best=moves[0];for(const move of moves){b[move]=ai;const value=minimax(b,human,0,-Infinity,Infinity);b[move]='';if(value>bestScore){bestScore=value;best=move}}return best}
function chooseAiMove(){const empty=emptyCells(board);if(!empty.length)return-1;if(mode==='easy'){const win=winningMove(board,ai);if(win>=0&&Math.random()<.62)return win;const block=winningMove(board,human);if(block>=0&&Math.random()<.48)return block;return empty[Math.floor(Math.random()*empty.length)]}if(mode==='normal'){const win=winningMove(board,ai);if(win>=0)return win;const block=winningMove(board,human);if(block>=0)return block;if(!board[4])return 4;return centerOrCorner(board)}return bestMove(board)}
function aiMove(){if(gameOver||busy||mode==='pvp'||turn!==ai)return;busy=true;hintCell=-1;render();const token=gameToken,move=chooseAiMove();window.clearTimeout(aiTimer);aiTimer=window.setTimeout(()=>{if(token!==gameToken){busy=false;render();return}if(!gameOver&&turn===ai&&move>=0&&board[move]==='')place(move,ai,true);busy=false;render()},mode==='hard'?110:75)}
function place(index,player,fromAi=false){if(gameOver||(busy&&!fromAi)||index<0||index>8||board[index])return false;if(turn!==player)return false;history.push(board.slice());board[index]=player;hintCell=-1;playSound('move');const result=checkResult(board);if(result){winningLine=result.line;gameOver=true;if(result.winner==='D')score.D+=1;else score[result.winner]+=1;saveState();render();showResult(result.winner);return true}turn=opponent(turn);render();if(mode!=='pvp'&&turn===ai)aiMove();return true}
function determineTurn(){const x=board.filter(v=>v==='X').length,o=board.filter(v=>v==='O').length;return x===o?'X':'O'}
function undo(){if(!history.length||gameOver||busy)return;const steps=mode==='pvp'?1:Math.min(2,history.length);for(let i=0;i<steps;i++)board=history.pop();turn=determineTurn();hintCell=-1;render();showToast(steps>1?'Dua langkah diurungkan.':'Satu langkah diurungkan.')}
function newRound(){gameToken+=1;window.clearTimeout(aiTimer);aiTimer=null;board=Array(9).fill('');turn='X';ai=opponent(human);if(mode==='pvp'){human='X';ai='O'}history=[];gameOver=false;busy=false;winningLine=[];hintCell=-1;overlay.classList.remove('show');round+=1;updateNames();render();if(mode!=='pvp'&&turn===ai)aiMove()}
function toggleSides(){if(mode==='pvp'){showToast('Tukar sisi hanya tersedia saat melawan Nano.');return}human=opponent(human);ai=opponent(human);saveState();newRound();showToast('Sisi ditukar. Kamu sekarang '+human+'.')}
function setMode(next){mode=next;if(mode==='pvp'){human='X';ai='O'}saveState();newRound();showToast(next==='pvp'?'Mode 2 pemain aktif.':'Mode '+({easy:'Santai',normal:'Seimbang',hard:'Tajam'}[next])+' aktif.')}
function resetScore(){score={X:0,O:0,D:0};saveState();render();showToast('Skor direset.')}
function giveHint(){if(gameOver||busy||turn!==human){showToast('Petunjuk tersedia saat giliran kamu.');return}let move=winningMove(board,human);if(move<0)move=winningMove(board,ai);if(move<0)move=mode==='hard'?bestMove(board):centerOrCorner(board);if(move<0){showToast('Belum ada langkah yang tersedia.');return}hintCell=move;render();showToast('Kotak berbingkai adalah petunjuk.')}
function updateNames(){nameXEl.textContent=mode==='pvp'?'Pemain X':human==='X'?'Kamu':'Nano';nameOEl.textContent=mode==='pvp'?'Pemain O':human==='O'?'Kamu':'Nano'}
function render(){boardEl.innerHTML='';for(let i=0;i<9;i++){const cell=document.createElement('button');cell.type='button';cell.className='cell '+(board[i]?board[i].toLowerCase():'empty');cell.dataset.pos=i;cell.dataset.num=i+1;cell.setAttribute('aria-label','Kotak '+(i+1)+(board[i]?' berisi '+board[i]:' kosong'));if(winningLine.includes(i))cell.classList.add('win');if(hintCell===i&&!board[i])cell.classList.add('hint');if(gameOver||busy||board[i]||(turn!==human&&mode!=='pvp'))cell.classList.add('locked');const symbol=document.createElement('span');symbol.className='symbol';symbol.textContent=board[i]||'';cell.appendChild(symbol);cell.addEventListener('click',()=>{if(mode==='pvp'||turn===human)place(i,turn)});boardEl.appendChild(cell)}statusEl.textContent=gameOver?'Ronde selesai':busy?'Nano berpikir':'Giliran '+turn;turnText.textContent=gameOver?'Ronde selesai':busy?'Nano sedang berpikir':(turn===human?'Kamu ('+turn+') sedang bermain':(mode==='pvp'?'Pemain '+turn+' sedang bermain':'Nano ('+turn+') sedang bermain'));roundText.textContent='Ronde '+round;scoreXEl.textContent=score.X;scoreOEl.textContent=score.O;scoreDEl.textContent=score.D;movesEl.textContent=9-emptyCells(board).length;subXEl.textContent=gameOver?'Selesai':turn==='X'?'Giliran aktif':'Menunggu';subOEl.textContent=gameOver?'Selesai':turn==='O'?'Giliran aktif':'Menunggu';playerXEl.classList.toggle('active',turn==='X'&&!gameOver);playerOEl.classList.toggle('active',turn==='O'&&!gameOver);noteEl.textContent=mode==='pvp'?'Dua pemain berbagi satu perangkat.': 'Kamu bermain sebagai '+human+'. Nano mengikuti tingkat '+({easy:'Santai',normal:'Seimbang',hard:'Tajam'}[mode])+'.';$('sound').textContent='♪ Suara: '+(soundOn?'Nyala':'Mati');$('undo').disabled=!history.length||gameOver||busy;updateNames()}
function showResult(winner){resultX.textContent=score.X;resultO.textContent=score.O;resultDraw.textContent=score.D;if(winner==='D'){resultIcon.textContent='≈';resultTitle.textContent='Seri';resultText.textContent='Semua kotak terisi. Ronde ini berakhir tanpa pemenang.';playSound('draw')}else{const who=mode==='pvp'?'Pemain '+winner:winner===human?'Kamu':'Nano';resultIcon.textContent=winner==='X'?'✕':'○';resultTitle.textContent=who+' menang';resultText.textContent='Tiga tanda bertemu dalam satu garis. Papan siap untuk ronde berikutnya.';playSound('win')}window.setTimeout(()=>overlay.classList.add('show'),80)}
function showToast(text){toast.textContent=text;toast.classList.add('show');window.clearTimeout(showToast.timer);showToast.timer=window.setTimeout(()=>toast.classList.remove('show'),1400)}
function playSound(type){if(!soundOn)return;try{audioCtx=audioCtx||(new(window.AudioContext||window.webkitAudioContext)());if(audioCtx.state==='suspended')audioCtx.resume();const o=audioCtx.createOscillator(),g=audioCtx.createGain(),now=audioCtx.currentTime,freq=type==='win'?720:type==='draw'?430:540;o.frequency.setValueAtTime(freq,now);o.frequency.exponentialRampToValueAtTime(type==='win'?920:370,now+.08);o.type=type==='move'?'sine':'triangle';g.gain.setValueAtTime(.04,now);g.gain.exponentialRampToValueAtTime(.001,now+.11);o.connect(g);g.connect(audioCtx.destination);o.start(now);o.stop(now+.11)}catch{}}
function keyHandler(e){if(e.key>='1'&&e.key<='9'&&!gameOver&&!busy){const idx=Number(e.key)-1;if(board[idx]===''&&(mode==='pvp'||turn===human))place(idx,turn);return}if(e.key.toLowerCase()==='r')newRound();if(e.key.toLowerCase()==='u')undo();if(e.key==='Escape')overlay.classList.remove('show')}
$('newGame').onclick=newRound;$('undo').onclick=undo;$('swap').onclick=toggleSides;$('sound').onclick=()=>{soundOn=!soundOn;saveState();render();if(soundOn)playSound('move')};$('resetScore').onclick=resetScore;$('hint').onclick=giveHint;$('playAgain').onclick=newRound;$('closeModal').onclick=()=>overlay.classList.remove('show');modeEl.onchange=e=>setMode(e.target.value);document.addEventListener('keydown',keyHandler);loadState();modeEl.value=mode;updateNames();newRound();
</script>
<script>
/* nano-guard-v2: (1) matikan menu tekan-lama/seleksi/seret, (2) geser di area permainan
   tidak menutup webview, (3) tombol balas SEKETIKA saat jari menyentuh supaya ambang
   tekan-lama WhatsApp tidak pernah tercapai (klik asli sesudahnya dimatikan). */
(function(){var D=document,i,evs=['contextmenu','selectstart','dragstart','gesturestart'];
for(i=0;i<evs.length;i++)D.addEventListener(evs[i],function(e){var t=e.target;if(t&&t.closest&&t.closest('textarea,input,[contenteditable]'))return;e.preventDefault()},false);
D.addEventListener('touchmove',function(e){var t=e.target,n;if(t&&t.closest&&t.closest('textarea,input,[contenteditable],.ovCard,.modal'))return;
for(n=t;n&&n!==D.body;n=n.parentElement)if(n.scrollHeight>n.clientHeight+4)return;
if(D.documentElement.scrollHeight>window.innerHeight+4)return;e.preventDefault()},{passive:false});
var sup=false,syn=false,PAD=/(btn|button|key|pad|tab|chip|cell|tile|card|lvt|opt|choice|pick|cmd|ctl|num|digit)/i;
function hit(el){for(var n=el,k=0;n&&n!==D.body&&k<5;n=n.parentElement,k++){var tn=n.tagName;
if(tn==='BUTTON'||tn==='A'||tn==='SUMMARY')return true;
if(n.getAttribute&&n.getAttribute('role')==='button')return true;
if(n.className&&typeof n.className==='string'&&PAD.test(n.className))return true}return false}
/* Satu ketukan = satu aksi: klik buatan kita dibedakan dari klik asli lewat isTrusted,
   jadi urutan keduanya tidak lagi bisa membuat aksi jalan dua kali. */
var g=null;
D.addEventListener('pointerdown',function(e){if(e.button)return;var t=e.target;
if(!t||!t.dispatchEvent||!hit(t))return;
if(t.closest&&t.closest('textarea,input,select,[contenteditable]'))return;
var x=e.clientX,y=e.clientY,gg={done:0};g=gg;
setTimeout(function(){
if(gg.done)return;gg.done=1;if(e.defaultPrevented)return;syn=true;
try{t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0}))}catch(err){}
syn=false;setTimeout(function(){if(g===gg)g=null},700)},0)},true);
D.addEventListener('click',function(e){
if(syn||!g)return;var gg=g;g=null;
if(!gg.done){gg.done=1;return}
if(e.isTrusted){e.stopPropagation();e.preventDefault()}},true)})();
</script>
<style>
html,body{overscroll-behavior:none;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}
img,canvas,svg{-webkit-user-drag:none;-webkit-touch-callout:none}
textarea,input,select,[contenteditable]{-webkit-user-select:text;user-select:text}
button,[role="button"],a,.btn,.key,.pad,.tab,.lvt,.chip,.cell,.tile,.card{-webkit-user-select:none;user-select:none;touch-action:manipulation}
canvas{touch-action:none}
</style>
<!-- nano-polish -->
<style>
/* lapisan kilap aditif: tidak mengubah tata letak, hanya rasa sentuh & ketajaman */
*{-webkit-tap-highlight-color:transparent;text-rendering:optimizeLegibility}
button,[role="button"],.btn,.key,.pad,a{-webkit-user-select:none;user-select:none;transition:transform .07s ease,filter .16s ease,box-shadow .22s ease}
button:active,[role="button"]:active,.btn:active,.key:active,.pad:active{transform:translateY(1px) scale(.985);filter:brightness(1.07)}
canvas,svg,img{-webkit-user-drag:none;user-select:none}
::selection{background:rgba(212,180,143,.35)}
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-thumb{background:rgba(212,180,143,.35);border-radius:99px}
::-webkit-scrollbar-track{background:transparent}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation-duration:.001ms!important}}
/* ── lapisan HD Nano ─────────────────────────────
   cahaya ruang dari kiri-atas + vignette + butiran halus supaya layar
   tidak terasa datar. Tidak mengubah tata letak sama sekali. */
html{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}
canvas,img,svg{-webkit-user-drag:none;-webkit-user-select:none;user-select:none}
html::after{content:"";position:fixed;inset:0;z-index:9;pointer-events:none;background-image:radial-gradient(122% 82% at 16% -12%,rgba(255,255,255,.11),rgba(255,255,255,0) 58%),radial-gradient(132% 112% at 92% 118%,rgba(0,0,0,.20),rgba(0,0,0,0) 62%),url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23n)' opacity='.06'/%3E%3C/svg%3E");background-size:auto,auto,160px 160px}
/* ── material v2: bevel + bayangan kontak supaya elemen terasa benda nyata ── */
.btn,.key,.chip,.chipBtn,.mini,.tab,.pad button{box-shadow:inset 0 1px 0 rgba(255,255,255,.16),inset 0 -2px 0 rgba(0,0,0,.42),0 7px 16px rgba(0,0,0,.45)}
.cell,.tile,.block,.pod{box-shadow:inset 0 1px 0 rgba(255,255,255,.24),inset 0 -2px 0 rgba(0,0,0,.3),0 3px 8px rgba(0,0,0,.42)}
.panel,.card,.stat,.stats,.modal,.grid,.board{box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 16px 36px rgba(0,0,0,.5),0 2px 0 rgba(0,0,0,.45)}
div:has(>canvas){position:relative;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.55),inset 0 0 0 1px rgba(255,255,255,.08)}
div:has(>canvas)>canvas{border-radius:10px;display:block}

/* ── material v3: kedalaman benda nyata: bevel, kilau, bayangan kontak ── */
/* gloss + kontak umum: dipakai kalau game tidak punya aturan khusus */
.btn,.chip,.chipBtn,.key,.mini,.tab{border-radius:11px!important;box-shadow:inset 0 2px 0 rgba(255,255,255,.22),inset 0 -3px 5px rgba(0,0,0,.42),0 4px 0 rgba(0,0,0,.42),0 8px 16px rgba(0,0,0,.4)!important}
.panel{border-radius:16px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.12),inset 0 -4px 12px rgba(0,0,0,.42),0 16px 36px rgba(0,0,0,.5),0 2px 0 rgba(0,0,0,.45)!important}
.boardFrame{border-radius:19px!important;box-shadow:inset 0 2px 0 rgba(255,255,255,.16),inset 0 -5px 14px rgba(0,0,0,.5),0 16px 36px rgba(0,0,0,.5),0 2px 0 rgba(0,0,0,.45)!important}
.cell{border-radius:12px!important;box-shadow:inset 0 2px 0 rgba(255,255,255,.22),inset 0 -3px 7px rgba(0,0,0,.38),0 4px 11px rgba(0,0,0,.42)!important}
.turnBar,.roundLine,.topControls{border-radius:12px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.16),0 6px 16px rgba(0,0,0,.42)!important}
</style>
</body>
</html>`

const handler = async (m, { conn }) => {
  if (!m?.chat || !conn) return

  const reactionKey = m?.raw?.key || m?.key
  if (reactionKey) await conn.sendMessage(m.chat, { react: { text: '✕○', key: reactionKey } }).catch(() => {})

  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {},
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 2,
                messageText: 'Nano Ai Tic Tac Toe ✕○',
              },
            ],
            unifiedResponse: {
              data: Buffer.from(
                JSON.stringify({
                  response_id: 'nano-ai-tictactoe-2026',
                  sections: [
                    {
                      view_model: {
                        primitive: {
                          __typename: 'GenAIaeacdsnwHtmlPrimitive',
                          payload: html,
                          trusted_sources: [],
                        },
                        __typename: 'GenAISingleLayoutViewModel',
                      },
                    },
                  ],
                })
              ).toString('base64'),
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: '867051314767696@bot',
              },
              forwardOrigin: 4,
            },
          },
        },
      },
    },
    {}
  )
}

handler.help = ['tictactoe', 'ttt', 'tic']
handler.tags = ['game']
handler.command = /^(tictactoe|ttt|tic)$/i
handler.category = 'game'
handler.groupOnly = false
handler.limit = false
handler.description = 'Game Tic Tac Toe Nano Ai dengan mode Santai, Seimbang, Tajam dan 2 Pemain'

export default handler
