/*
⌬
┇ ━━━[ 🥳 𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗕𝗥𝗢𝗞 ]━━━━
┇
┇ ❘█▀█ █ █▀█ █▀█   ▄▀█ █
┇ █  █ █ █▀▄ █▄█   █▀█ █    
┇  ▀█  --N--a--n--o------A--i-----
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ 💬 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ]━━━━
┇
┇▫️Author  : Danz nano & Awang Ofc 
┇▫️Website  : awangofc.my.id
┇▫️WhatsApp : wa.me/556184127506
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ ✍️ 𝗖𝗔𝗧𝗔𝗧𝗔𝗡 ]━━━━
┇
┇🔸Dilarang Menghapus Creadit SC
┇🔸Dilarang Menjual Script Nano Ai
┇🔸Dilarang Mengatas Namakan Script!!
⌬
*/

const html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<title>Nano Ai TTS</title>
<style>
:root{--bg:#151515;--surface:#222;--surface2:#1a1a1a;--edge:#3a3a3a;--text:#f4f2ea;--muted:#aaa79f;--accent:#b9ef63;--accent2:#7ed7a0;--shadow:#090909;--shine:#343434;--danger:#f08b94;--gold:#d7ae67}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;min-height:100%;background:linear-gradient(150deg,#171717,#101010 55%,#1b1b1b);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}
body{padding:8px;overflow-x:hidden}.app{width:min(100%,760px);margin:auto}.shell{padding:10px;border-radius:23px;background:linear-gradient(145deg,#282828,#171717);box-shadow:8px 8px 16px var(--shadow),-5px -5px 10px #303030;border:1px solid #333}
.header{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:8px}.brand{display:flex;align-items:center;gap:9px;min-width:0}.logo{width:46px;height:46px;flex:none;border-radius:14px;display:grid;place-items:center;background:linear-gradient(145deg,#303030,#1d1d1d);box-shadow:5px 5px 10px #0b0b0b,-4px -4px 8px #383838;color:var(--accent);font-size:22px;border:1px solid #3b3b3b}.title{font-size:20px;font-weight:950;letter-spacing:-.4px}.sub{margin-top:2px;font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.status{padding:9px 11px;border-radius:11px;background:linear-gradient(145deg,#252525,#1b1b1b);box-shadow:4px 4px 8px #0c0c0c,-3px -3px 6px #323232;border:1px solid #3b3b3b;color:var(--accent);font-size:8.5px;font-weight:950;letter-spacing:.55px;white-space:nowrap}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-bottom:8px}.stat{min-width:0;padding:8px 8px 7px;border-radius:14px;background:linear-gradient(145deg,#2a2a2a,#1b1b1b);box-shadow:4px 4px 8px #0d0d0d,-3px -3px 7px #323232;border:1px solid #393939}.stat b{display:block;font-size:18px;line-height:1.05}.stat span{display:block;margin-top:3px;font-size:8.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.65px}
.gameLayout{display:grid;grid-template-columns:minmax(0,1.04fr) minmax(275px,.96fr);gap:9px;align-items:start}.boardCard,.cluePanel{min-width:0;background:linear-gradient(145deg,#282828,#1b1b1b);border:1px solid #3a3a3a}.boardCard{padding:9px;border-radius:20px;box-shadow:6px 6px 12px #0a0a0a,-4px -4px 8px #303030}.boardHead{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:0 2px 6px}.sectionTag{font-size:10px;font-weight:950;letter-spacing:.62px;color:var(--accent)}.sectionHint{font-size:9px;color:var(--muted);text-align:right}.boardWrap{position:relative;width:min(100%,500px);margin:auto;padding:8px;border-radius:18px;background:#1a1a1a;box-shadow:inset 4px 4px 8px #0b0b0b,inset -3px -3px 6px #2f2f2f;border:1px solid #343434}.grid{display:grid;grid-template-columns:repeat(11,1fr);width:100%;aspect-ratio:1/1;gap:2px;padding:2px;border-radius:12px;background:#101010;box-shadow:inset 2px 2px 4px #050505,inset -2px -2px 4px #262626}.cell{position:relative;min-width:0;min-height:0;border:0;border-radius:5px;background:linear-gradient(145deg,#303030,#242424);box-shadow:2px 2px 3px #0e0e0e,-1px -1px 2px #3a3a3a}.cell.block{background:#141414;box-shadow:inset 1px 1px 2px #090909,inset -1px -1px 1px #232323}.cell input{position:absolute;inset:0;width:100%;height:100%;border:0;outline:0;background:transparent;color:#f5f4ed;text-align:center;font:950 clamp(15px,3.7vw,24px)/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;text-transform:uppercase;padding:0;caret-color:var(--accent);text-shadow:0 1px 0 #000}.cell input:focus{background:#34402b;box-shadow:inset 0 0 0 2px #b9ef63}.cell.word input{background:#ffffff05}.cell.correct input{background:#42572f;color:#efffcf}.cell.wrong input{background:#593239;color:#ffdbe1}.cell .num{position:absolute;left:3px;top:2px;font-size:clamp(6px,1.35vw,9px);line-height:1;color:#dedfd6;opacity:.7;pointer-events:none;z-index:2}
.cluePanel{padding:9px;border-radius:19px;box-shadow:6px 6px 12px #0b0b0b,-4px -4px 8px #303030}.clueTop{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:7px}.clueTitle{font-size:11px;font-weight:950;letter-spacing:.5px}.clueMode{display:flex;gap:5px}.tab{border:1px solid #414141;border-radius:10px;padding:8px 10px;background:linear-gradient(145deg,#292929,#1b1b1b);color:#b9b7af;font:900 9px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;box-shadow:3px 3px 6px #0b0b0b,-2px -2px 4px #303030;cursor:pointer}.tab.active{color:#17210f;background:linear-gradient(145deg,#c6f47a,#9ccb54);border-color:#d8ff9588}.clues{display:grid;gap:6px;max-height:238px;overflow:auto;padding:1px 2px 3px 1px}.clues.hidden{display:none}.clue{display:grid;grid-template-columns:35px 1fr;gap:9px;align-items:start;width:100%;border:1px solid #414141;border-radius:12px;background:linear-gradient(145deg,#292929,#1b1b1b);color:#ecebe4;text-align:left;padding:8px 9px;font:800 12px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;box-shadow:3px 3px 6px #0d0d0d,-2px -2px 4px #303030}.clue b{display:grid;place-items:center;width:31px;height:28px;border-radius:7px;background:linear-gradient(145deg,#323232,#202020);color:var(--accent);box-shadow:inset 1px 1px 2px #111,inset -1px -1px 2px #3a3a3a;font-size:9.5px}.clue.active{border-color:#b9ef6377;box-shadow:inset 0 0 0 1px #b9ef6333,3px 3px 6px #0d0d0d,-2px -2px 4px #303030}
.actions{display:grid;grid-template-columns:1.15fr 1fr;gap:8px;margin-top:9px}.btn{min-height:54px;border:1px solid #424242;border-radius:14px;background:linear-gradient(145deg,#2b2b2b,#1b1b1b);color:#f4f3ec;font:950 12px/1 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;touch-action:manipulation;cursor:pointer;box-shadow:5px 5px 9px #0d0d0d,-4px -4px 7px #333}.btn:active{transform:translateY(1px);box-shadow:inset 3px 3px 6px #101010,inset -2px -2px 4px #313131}.btn.primary{color:#17210f;background:linear-gradient(145deg,#d4fb82,#a8d55b);border-color:#d9ff9588}.btn.good{color:#eaffef;background:linear-gradient(145deg,#35513c,#263b2d);border-color:#6da47a80}.btn.gold{color:#fff4d3;background:linear-gradient(145deg,#5b4a2f,#3d321f);border-color:#a58c51aa}
.tools{margin-top:8px;border-radius:14px;border:1px solid #393939;background:linear-gradient(145deg,#242424,#1a1a1a);box-shadow:inset 1px 1px 2px #313131,inset -1px -1px 2px #111}.tools summary{list-style:none;cursor:pointer;padding:9px 12px;font-size:10.5px;font-weight:900;color:#d0cfc7}.tools summary::-webkit-details-marker{display:none}.tools summary span{float:right;color:var(--muted);font-size:9.5px}.toolsBody{display:grid;grid-template-columns:1fr 1fr;gap:7px;padding:0 9px 9px}.toolBtn{min-height:46px}.metaBar{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:8px}.metaPanel{min-width:0;padding:9px;border-radius:14px;background:linear-gradient(145deg,#252525,#1b1b1b);border:1px solid #383838;box-shadow:4px 4px 8px #0b0b0b,-3px -3px 6px #303030}.metaPanel.compact{display:flex;align-items:center;justify-content:space-between;gap:7px}.metaLabel{font-size:8.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.55px}.metaValue{font-size:12.5px;font-weight:900;color:#f0efe8}.progress{height:7px;margin-top:7px;padding:1px;border-radius:99px;background:#151515;box-shadow:inset 1px 1px 3px #090909,inset -1px -1px 2px #272727;overflow:hidden}.progress i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--accent2),var(--accent));border-radius:99px;transition:width .1s linear}.hint{margin-top:6px;padding:8px 9px;border-radius:10px;background:#1a1a1a;color:#aaa79f;text-align:center;font-size:9.3px;line-height:1.4;box-shadow:inset 1px 1px 3px #0c0c0c,inset -1px -1px 2px #2c2c2c}
@media (max-width:560px){.shell{padding:9px}.header{gap:9px}.logo{width:48px;height:48px;font-size:23px}.title{font-size:20px}.sub{font-size:10px}.stats{gap:6px}.stat{padding:8px 7px}.stat b{font-size:18px}.stat span{font-size:8px}.boardCard,.cluePanel{padding:9px}.boardWrap{padding:8px}.grid{gap:2px}.clue{font-size:11.7px;padding:8px 9px}.clue b{width:31px;height:28px;font-size:9px}.clues{max-height:236px}.btn{min-height:52px;font-size:11.8px}.metaBar{gap:6px}.metaPanel{padding:8px}.metaLabel{font-size:8px}.metaValue{font-size:12px}.hint{font-size:9px}}
.overlay{position:fixed;inset:0;z-index:30;display:flex;align-items:center;justify-content:center;padding:16px;background:#0a0a0ad9}.overlay.hide{display:none}.modal{width:min(92vw,420px);padding:19px;border-radius:21px;background:linear-gradient(145deg,#2a2a2a,#191919);border:1px solid #424242;box-shadow:10px 10px 20px #090909,-7px -7px 14px #343434;text-align:center}.hero{width:70px;height:70px;margin:auto auto 8px;border-radius:19px;display:grid;place-items:center;background:linear-gradient(145deg,#2e2e2e,#1d1d1d);box-shadow:7px 7px 12px #0d0d0d,-5px -5px 10px #393939;border:1px solid #404040;font-size:36px}.modal h2{margin:3px 0;font-size:22px}.modal p{margin:8px 0 14px;color:var(--muted);font-size:10.5px;line-height:1.45}.result{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-bottom:12px}.result div{padding:9px;border-radius:12px;background:linear-gradient(145deg,#292929,#1b1b1b);border:1px solid #414141;box-shadow:4px 4px 7px #0e0e0e,-3px -3px 6px #333}.result b{display:block;font-size:16px}.result span{font-size:8px;color:var(--muted)}.modalBtns{display:grid;grid-template-columns:1fr 1fr;gap:8px}.toast{position:fixed;z-index:40;left:50%;bottom:82px;transform:translate(-50%,10px);opacity:0;pointer-events:none;padding:9px 12px;border-radius:11px;background:#252525;border:1px solid #515151;color:#f6f6ef;font-size:9.5px;font-weight:900;box-shadow:6px 6px 12px #0a0a0a,-4px -4px 8px #343434;white-space:nowrap}.toast.show{opacity:1;transform:translate(-50%,0)}
@media(max-width:720px){.gameLayout{grid-template-columns:1fr}.clues{max-height:215px}}
@media(max-width:560px){body{padding:7px}.shell{padding:8px;border-radius:21px}.header{margin-bottom:7px}.logo{width:44px;height:44px}.title{font-size:17px}.sub{font-size:9px}.stats{gap:6px}.stat{padding:8px 7px}.stat b{font-size:15px}.stat span{font-size:7px}.boardCard{padding:8px}.boardWrap{padding:7px}.boardHead{padding-bottom:6px}.sectionHint{display:none}.cluePanel{padding:8px}.clues{max-height:205px}.clue{font-size:10px;padding:8px}.actions{gap:7px}.btn{min-height:50px;font-size:10px}.toolsBody{grid-template-columns:1fr 1fr}.toolBtn{min-height:43px}.metaBar{grid-template-columns:repeat(4,1fr);gap:5px}.metaPanel{padding:8px 7px;text-align:center}.metaPanel.compact{display:block}.metaValue{display:block;margin-top:3px;font-size:10.5px}.metaLabel{font-size:6.8px}.modalBtns{gap:7px}}
@media(max-width:390px){.stats{gap:5px}.stat{padding:7px 5px}.stat b{font-size:14px}.stat span{font-size:6.6px}.clueTop{gap:5px}.tab{padding:7px 8px}.clues{max-height:185px}.clue{grid-template-columns:29px 1fr;gap:7px;font-size:9.4px}.clue b{width:25px;height:23px}.actions{grid-template-columns:1fr 1fr}.btn{min-height:48px;font-size:9.3px}.metaValue{font-size:10px}.metaLabel{font-size:6.3px}}
</style>
</head>
<body>
<div class="app">
<div class="shell">
<div class="header"><div class="brand"><div class="logo">🧩</div><div><div class="title">Nano Ai TTS</div><div class="sub">Neumorphic Crossword • Santai, Tajam, Menantang</div></div></div><div class="status" id="status">PUZZLE 1</div></div>
<div class="stats"><div class="stat"><b id="score">0</b><span>Score</span></div><div class="stat"><b id="best">0</b><span>Best</span></div><div class="stat"><b id="timer">00:00</b><span>Waktu</span></div><div class="stat"><b id="progressText">0%</b><span>Terisi</span></div></div>
<div class="gameLayout"><div class="boardCard"><div class="boardHead"><span class="sectionTag">CROSSWORD LAB</span><span class="sectionHint">Teknologi • sains • keseharian</span></div><div class="boardWrap"><div class="grid" id="grid"></div></div></div><div class="cluePanel"><div class="clueTop"><div class="clueTitle">PETUNJUK</div><div class="clueMode"><button class="tab active" id="acrossTab" type="button">MENDATAR <span id="acrossCount">0</span></button><button class="tab" id="downTab" type="button">MENURUN <span id="downCount">0</span></button></div></div><div class="clues" id="across"></div><div class="clues hidden" id="down"></div></div></div>
<div class="actions"><button class="btn primary" id="checkBtn" type="button">✓ CEK JAWABAN</button><button class="btn good" id="hintBtn" type="button">✦ PETUNJUK</button></div>
<details class="tools"><summary>Pengaturan & alat <span>opsional</span></summary><div class="toolsBody"><button class="btn gold toolBtn" id="resetBtn" type="button">↻ RESET</button><button class="btn toolBtn" id="nextBtn" type="button">→ PUZZLE</button></div></details>
<div class="metaBar"><div class="metaPanel compact"><span class="metaLabel">Kesalahan</span><b class="metaValue" id="mistakes">0</b></div><div class="metaPanel compact"><span class="metaLabel">Petunjuk</span><b class="metaValue" id="hints">0</b></div><div class="metaPanel compact"><span class="metaLabel">Kata</span><b class="metaValue" id="solvedWords">0 / 0</b></div><div class="metaPanel compact"><span class="metaLabel">Bonus</span><b class="metaValue" id="timeBonus">0</b></div><div class="metaPanel"><div class="metaLabel">Terisi <b class="metaValue" id="progressText">0%</b></div><div class="progress"><i id="progressBar"></i></div></div></div>
<div class="hint">Tap nomor atau kotak • ketik huruf • panah untuk pindah</div>
</div>
</div>
<div class="overlay hide" id="overlay"><div class="modal"><div class="hero">🏆</div><h2 id="resultTitle">Puzzle Selesai</h2><p id="resultText">Kamu berhasil menyelesaikan semua kata.</p><div class="result"><div><b id="resultScore">0</b><span>SCORE</span></div><div><b id="resultTime">00:00</b><span>WAKTU</span></div><div><b id="resultBest">0</b><span>BEST</span></div></div><div class="modalBtns"><button class="btn primary" id="playAgain" type="button">↻ MAIN LAGI</button><button class="btn" id="closeModal" type="button">TUTUP</button></div></div></div><div class="toast" id="toast"></div>
<script>
(function(){
var $=function(id){return document.getElementById(id)};var gridEl=$('grid'),acrossEl=$('across'),downEl=$('down'),overlay=$('overlay'),toastEl=$('toast');var acrossTab=$('acrossTab'),downTab=$('downTab');var cells=[],cellWords=[],words=[],activeWord=null,activeDir='across',activeCell=0,puzzleIndex=0,elapsed=0,tick=0,uiTick=0,mistakes=0,hints=0,finished=false,score=0,best=0;
var puzzles=[
{name:'Teknologi & Internet',words:[['SERVER','Komputer yang menyediakan layanan untuk perangkat atau aplikasi lain.'],['JARINGAN','Kumpulan perangkat yang saling terhubung untuk bertukar data.'],['BROWSER','Aplikasi yang digunakan untuk membuka dan menjelajahi halaman web.'],['KODE','Serangkaian instruksi yang ditulis agar komputer menjalankan tugas tertentu.'],['DATA','Kumpulan fakta atau informasi yang dapat disimpan dan diolah.'],['DIGITAL','Sesuatu yang berkaitan dengan data berbasis sistem elektronik.'],['APLIKASI','Perangkat lunak yang dibuat untuk kebutuhan atau fungsi tertentu.'],['ALGORITMA','Langkah logis dan terstruktur untuk menyelesaikan sebuah masalah.'],['PROGRAM','Sekumpulan instruksi yang membuat komputer melakukan pekerjaan tertentu.'],['PASSWORD','Kata atau rangkaian karakter untuk mengamankan akses akun.'],['CLOUD','Layanan penyimpanan atau komputasi yang diakses melalui internet.'],['BOT','Program otomatis yang dapat menjalankan tugas atau merespons perintah.']]},
{name:'Alam & Sains',words:[['GUNUNG','Bentang alam tinggi yang menjulang jauh di atas wilayah sekitarnya.'],['SUNGAI','Aliran air alami yang bergerak dari daerah tinggi menuju daerah lebih rendah.'],['HUJAN','Air dari atmosfer yang jatuh ke permukaan bumi dalam bentuk tetesan.'],['HUTAN','Wilayah luas yang didominasi pepohonan dan berbagai makhluk hidup.'],['LAUT','Perairan asin yang sangat luas dan menjadi bagian penting ekosistem bumi.'],['BUNGA','Bagian tumbuhan yang umumnya berperan dalam proses perkembangbiakan.'],['ANGIN','Gerakan udara dari satu wilayah menuju wilayah lainnya.'],['PLANET','Benda langit yang mengorbit bintang dan memiliki massa cukup besar.'],['ENERGI','Kemampuan suatu sistem untuk melakukan kerja atau menghasilkan perubahan.'],['ATOM','Unit dasar penyusun unsur yang memiliki inti dan elektron.'],['SEL','Unit terkecil kehidupan yang menyusun organisme.'],['GALAKSI','Sistem besar berisi bintang, gas, debu, dan objek langit lainnya.']]},
{name:'Keseharian & Kreatif',words:[['MUSIK','Seni yang tersusun dari bunyi, irama, melodi, atau harmoni.'],['CERITA','Rangkaian peristiwa yang disampaikan sebagai sebuah kisah.'],['KAMERA','Perangkat yang digunakan untuk menangkap gambar atau video.'],['FILM','Karya audiovisual yang menyampaikan cerita melalui gambar bergerak dan suara.'],['BUKU','Kumpulan halaman yang memuat tulisan, gambar, atau informasi.'],['SEPATU','Alas kaki yang dirancang untuk melindungi dan menopang kaki.'],['PASAR','Tempat terjadinya kegiatan jual beli barang atau jasa.'],['KOTA','Wilayah dengan kepadatan penduduk dan aktivitas ekonomi yang relatif tinggi.'],['JALAN','Jalur yang digunakan orang atau kendaraan untuk berpindah tempat.'],['KOPI','Minuman yang dibuat dari biji tanaman yang disangrai dan diseduh.'],['WAKTU','Ukuran yang digunakan untuk menggambarkan urutan dan durasi suatu kejadian.'],['IDE','Gagasan atau pemikiran yang dapat menjadi dasar sebuah karya atau tindakan.']] }
]
function loadBest(){try{return Number(localStorage.getItem('nano_tts_best')||0)||0}catch(e){return 0}}function saveBest(v){try{localStorage.setItem('nano_tts_best',String(v))}catch(e){}}
best=loadBest();$('best').textContent=best;
function fmtTime(sec){sec=Math.max(0,Math.floor(sec));var m=Math.floor(sec/60).toString().padStart(2,'0'),s=(sec%60).toString().padStart(2,'0');return m+':'+s}
function toast(t){toastEl.textContent=t;toastEl.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(function(){toastEl.classList.remove('show')},1000)}
function buildGrid(){var p=puzzles[puzzleIndex],n=11,matrix=Array.from({length:n},function(){return Array(n).fill('#')});words=[];var items=p.words.slice().sort(function(a,b){return b[0].length-a[0].length}),placed=[];function canPlace(word,r,c,dir){var dr=dir==='down'?1:0,dc=dir==='across'?1:0;if(r<0||c<0||r+dr*(word.length-1)>=n||c+dc*(word.length-1)>=n)return false;for(var k=0;k<word.length;k++){var rr=r+dr*k,cc=c+dc*k,ch=matrix[rr][cc];if(ch!=='#'&&ch!==word[k])return false}return true}function put(word,r,c,dir){var dr=dir==='down'?1:0,dc=dir==='across'?1:0,cs=[];for(var k=0;k<word.length;k++){var rr=r+dr*k,cc=c+dc*k;matrix[rr][cc]=word[k];cs.push(rr*n+cc)}var obj={word:word,r:r,c:c,dir:dir,cells:cs,number:0};placed.push(obj);return obj}if(items.length){var first=items.shift();put(first[0],Math.floor(n/2),Math.max(0,Math.floor((n-first[0].length)/2)),'across')}for(var ii=0;ii<items.length;ii++){var item=items[ii],word=item[0],clue=item[1],bestPos=null;for(var pi=0;pi<placed.length&&!bestPos;pi++){var base=placed[pi],bd=base.dir==='across'?'down':'across';for(var a=0;a<base.word.length&&!bestPos;a++){var letter=base.word[a];for(var b=0;b<word.length&&!bestPos;b++){if(word[b]!==letter)continue;var dr=bd==='down'?1:0,dc=bd==='across'?1:0,rr=base.r+(base.dir==='down'?a:0)-(bd==='down'?b:0),cc=base.c+(base.dir==='across'?a:0)-(bd==='across'?b:0);if(canPlace(word,rr,cc,bd))bestPos={r:rr,c:cc,dir:bd}}}}if(!bestPos){outer:for(var r=0;r<n;r++)for(var c=0;c<n;c++)for(var d=0;d<2;d++){var dir=d?'down':'across';if(canPlace(word,r,c,dir)){bestPos={r:r,c:c,dir:dir};break outer}}}if(bestPos)put(word,bestPos.r,bestPos.c,bestPos.dir)}var starts={};placed.forEach(function(w){var key=w.r*n+w.c;if(starts[key]==null)starts[key]=0});var keys=Object.keys(starts).map(Number).sort(function(a,b){return a-b}),nums={};keys.forEach(function(k,i){nums[k]=i+1});placed.forEach(function(w,i){w.number=nums[w.r*n+w.c]||i+1;w.clue=items.find(function(x){return x[0]===w.word})?.[1]||p.words.find(function(x){return x[0]===w.word})?.[1]||''});words=placed;return matrix}
function render(){var matrix=buildGrid(),n=11;gridEl.innerHTML='';cells=[];cellWords=Array.from({length:n*n},function(){return[]});for(var wi=0;wi<words.length;wi++)words[wi].cells.forEach(function(idx){if(cellWords[idx].indexOf(wi)<0)cellWords[idx].push(wi)});var starts={};words.forEach(function(w){starts[w.r*n+w.c]=w.number});for(var i=0;i<n*n;i++){var r=Math.floor(i/n),c=i%n,wrap=document.createElement('div');wrap.className='cell '+(matrix[r][c]==='#'?'block':'');if(matrix[r][c]!=='#'){var inp=document.createElement('input');inp.maxLength=1;inp.autocomplete='off';inp.autocapitalize='characters';inp.spellcheck=false;inp.inputMode='text';inp.dataset.index=i;inp.dataset.answer=matrix[r][c];inp.addEventListener('focus',function(){activeCell=Number(this.dataset.index);chooseDirection();updateActive()});inp.addEventListener('input',function(){this.value=this.value.replace(/[^a-zA-ZÀ-ÿ]/g,'').slice(-1).toUpperCase();this.parentElement.classList.remove('wrong','correct');if(this.value)moveNext(Number(this.dataset.index));updateStats()});inp.addEventListener('keydown',function(e){keyNav(e,this)});wrap.appendChild(inp);cells[i]=inp;if(starts[i]){var nEl=document.createElement('span');nEl.className='num';nEl.textContent=starts[i];wrap.appendChild(nEl)}}else cells[i]=null;wrap.addEventListener('pointerdown',function(){var inp=this.querySelector('input');if(inp){activeCell=Number(inp.dataset.index);chooseDirection();setTimeout(function(){inp.focus()},0)}});gridEl.appendChild(wrap)}
acrossEl.innerHTML='';downEl.innerHTML='';var used={};words.forEach(function(w,wi){var key=w.number+'-'+w.dir;if(used[key])return;used[key]=1;var b=document.createElement('button');b.type='button';b.className='clue';b.dataset.word=wi;var nb=document.createElement('b');nb.textContent=w.number;var tx=document.createElement('span');tx.textContent=w.clue;b.appendChild(nb);b.appendChild(tx);b.addEventListener('click',function(){selectWord(words[Number(this.dataset.word)])});(w.dir==='across'?acrossEl:downEl).appendChild(b)});$('acrossCount').textContent=acrossEl.children.length+' kata';$('downCount').textContent=downEl.children.length+' kata';updateActive();updateStats()}
function selectWord(w){if(!w)return;activeWord=w;activeDir=w.dir;activeCell=w.cells[0];updateActive();cells[activeCell]?.focus()}
function chooseDirection(){var candidates=cellWords[activeCell]||[];if(!candidates.length)return;if(activeWord&&activeWord.cells.indexOf(activeCell)>=0){var same=candidates.find(function(i){return words[i]===activeWord});if(candidates.length>1&&same!=null){var other=candidates.find(function(i){return words[i].dir!==activeDir});if(other!=null){activeDir=words[other].dir;activeWord=words[other]}}}if(!activeWord||activeWord.cells.indexOf(activeCell)<0||activeWord.dir!==activeDir){var cand=candidates.find(function(i){return words[i].dir===activeDir})??candidates[0];activeWord=words[cand];activeDir=activeWord.dir}}
function updateActive(){cells.forEach(function(inp){if(!inp)return;var idx=Number(inp.dataset.index),wrap=inp.parentElement;wrap.classList.remove('word','active');if(activeWord&&activeWord.cells.indexOf(idx)>=0)wrap.classList.add('word');if(idx===activeCell)wrap.classList.add('active')});Array.prototype.forEach.call(document.querySelectorAll('.clue'),function(b){b.classList.toggle('active',Number(b.dataset.word)===words.indexOf(activeWord))})}
function moveNext(idx){var list=activeWord?.cells||[],p=list.indexOf(idx);if(p>=0&&p+1<list.length){activeCell=list[p+1];cells[activeCell]?.focus();updateActive()}}
function keyNav(e,input){var i=Number(input.dataset.index);if(e.key==='Backspace'&&!input.value){e.preventDefault();var list=activeWord?.cells||[],p=list.indexOf(i);if(p>0){activeCell=list[p-1];cells[activeCell]?.focus();updateActive()}return}if(e.key==='ArrowRight'||e.key==='ArrowLeft'||e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();var n=11,r=Math.floor(i/n),c=i%n,rr=r,cc=c;if(e.key==='ArrowRight')cc++;if(e.key==='ArrowLeft')cc--;if(e.key==='ArrowUp')rr--;if(e.key==='ArrowDown')rr++;if(rr>=0&&rr<n&&cc>=0&&cc<n&&cells[rr*n+cc]){activeCell=rr*n+cc;chooseDirection();cells[activeCell].focus();updateActive()}}}
function wordSolved(w){return w.cells.every(function(idx){return cells[idx]&&cells[idx].value.toUpperCase()===w.word[w.cells.indexOf(idx)]})}
function allSolved(){return words.length>0&&words.every(wordSolved)}
function updateStats(){if(!words.length)return;var total=0,filled=0,solved=0;for(var i=0;i<cells.length;i++){if(!cells[i])continue;total++;if(cells[i].value)filled++}words.forEach(function(w){if(wordSolved(w))solved++});var pct=total?Math.round(filled/total*100):0;if(filled>0){var earned=filled*8+solved*55;score=Math.max(score,earned)}$('score').textContent=Math.max(0,score);$('best').textContent=Math.max(best,score);$('timer').textContent=fmtTime(elapsed);$('progressText').textContent=pct+'%';$('progressBar').style.width=pct+'%';$('mistakes').textContent=mistakes;$('hints').textContent=hints;$('solvedWords').textContent=solved+' / '+words.length;var tb=$('timeBonus');if(tb)tb.textContent=Math.max(0,Math.floor(600-Math.min(600,elapsed*4)));if(!finished&&allSolved())finish()}
function check(){if(finished)return;var errors=0;for(var i=0;i<cells.length;i++){var inp=cells[i];if(!inp)continue;if(inp.value){var ok=inp.value===inp.dataset.answer;inp.parentElement.classList.toggle('correct',ok);inp.parentElement.classList.toggle('wrong',!ok);if(!ok)errors++}}if(errors){window.GX&&GX.blip(300,180,.14,.045);window.GX&&GX.vib(14);mistakes+=errors;score=Math.max(0,score-errors*20);toast(errors+' huruf belum tepat')}else{window.GX&&GX.blip(880,1240,.12,.05);toast('Semua huruf yang diisi sudah tepat ✓')}updateStats()}
function hint(){if(finished)return;var candidates=activeWord?.cells||[];var target=candidates.find(function(i){return cells[i]&&!cells[i].value});if(target==null)target=cells.findIndex(function(x){return x&&!x.value});if(target<0){toast('Tidak ada huruf yang bisa dibuka');return}var inp=cells[target];inp.value=inp.dataset.answer;inp.parentElement.classList.remove('wrong');inp.parentElement.classList.add('correct');hints++;score=Math.max(0,score-75);activeCell=target;chooseDirection();inp.focus();updateActive();toast('1 huruf dibuka ✦');updateStats()}
function resetPuzzle(){if(finished){startPuzzle(puzzleIndex);return}for(var i=0;i<cells.length;i++)if(cells[i]){cells[i].value='';cells[i].parentElement.classList.remove('wrong','correct')}elapsed=0;mistakes=0;hints=0;score=0;activeWord=words[0]||null;activeDir=activeWord?.dir||'across';activeCell=activeWord?.cells[0]||0;updateActive();updateStats();cells[activeCell]?.focus();toast('Puzzle direset')}
function nextPuzzle(){startPuzzle((puzzleIndex+1)%puzzles.length)}
function startPuzzle(index){puzzleIndex=index;elapsed=0;tick=0;uiTick=0;mistakes=0;hints=0;score=0;finished=false;activeWord=null;activeDir='across';activeCell=0;overlay.classList.add('hide');$('status').textContent='PUZZLE '+(puzzleIndex+1);render();activeWord=words[0]||null;activeDir=activeWord?.dir||'across';activeCell=activeWord?.cells[0]||0;updateActive();cells[activeCell]?.focus()}
function finish(){window.GX&&GX.blip(700,1180,.3,.06);window.GX&&GX.vib([20,40,60]);finished=true;var timeBonus=Math.max(0,600-Math.floor(elapsed*4));var speedBonus=elapsed<60?300:elapsed<120?150:0;var accuracyBonus=Math.max(0,300-mistakes*35-hints*75);score=1000+timeBonus+speedBonus+accuracyBonus;if(score>best){best=score;saveBest(best)}$('best').textContent=best;$('resultScore').textContent=score;$('resultTime').textContent=fmtTime(elapsed);$('resultBest').textContent=best;$('resultTitle').textContent='Crossword Selesai!';$('resultText').textContent='Semua kata berhasil dipecahkan. Bonus waktu dan akurasi sudah dihitung.';overlay.classList.remove('hide')}
function gameTick(now){if(!tick)tick=now;var dt=Math.min(.25,(now-tick)/1000);tick=now;if(!finished){elapsed+=dt;uiTick+=dt;if(uiTick>=.1){uiTick=0;updateStats()}}requestAnimationFrame(gameTick)}
function showClueTab(mode){var isAcross=mode==='across';acrossEl.classList.toggle('hidden',!isAcross);downEl.classList.toggle('hidden',isAcross);acrossTab.classList.toggle('active',isAcross);downTab.classList.toggle('active',!isAcross)}acrossTab.addEventListener('click',function(){showClueTab('across')});downTab.addEventListener('click',function(){showClueTab('down')});$('checkBtn').addEventListener('click',check);$('hintBtn').addEventListener('click',hint);$('resetBtn').addEventListener('click',resetPuzzle);$('nextBtn').addEventListener('click',nextPuzzle);$('playAgain').addEventListener('click',function(){startPuzzle(puzzleIndex)});$('closeModal').addEventListener('click',function(){overlay.classList.add('hide')});document.addEventListener('visibilitychange',function(){if(document.hidden)tick=performance.now()});window.addEventListener('resize',updateActive);startPuzzle(0);requestAnimationFrame(gameTick)
})();
</script>
<script>
(function(){var A=null,on=true;function ac(){try{if(!A){var C=window.AudioContext||window.webkitAudioContext;if(C)A=new C()}if(A&&A.state==='suspended')A.resume()}catch{}}
function blip(f1,f2,d,v,t){if(!on)return;ac();if(!A)return;try{var n=A.currentTime,o=A.createOscillator(),g=A.createGain();o.type=t||'square';o.frequency.setValueAtTime(f1,n);if(f2)o.frequency.exponentialRampToValueAtTime(f2,n+d);g.gain.setValueAtTime(.0001,n);g.gain.exponentialRampToValueAtTime(v||.05,n+.015);g.gain.exponentialRampToValueAtTime(.0001,n+d);o.connect(g);g.connect(A.destination);o.start(n);o.stop(n+d+.03)}catch{}}
function vib(p){if(!on)return;try{if(navigator.vibrate)navigator.vibrate(p)}catch{}}
window.GX={blip:blip,vib:vib,unlock:ac,isOn:function(){return on}};
document.addEventListener('pointerdown',ac,{passive:true});document.addEventListener('keydown',ac,{passive:true});
try{var b=document.createElement('button');b.type='button';b.textContent='\uD83D\uDD0A';b.setAttribute('aria-label','Suara');
b.style.cssText='position:fixed;right:10px;bottom:10px;z-index:2147483000;width:36px;height:36px;border-radius:50%;border:1px solid rgba(255,255,255,.22);background:rgba(16,22,26,.82);color:#e9f1ef;font-size:15px;line-height:1;box-shadow:0 6px 16px rgba(0,0,0,.45)';
b.onclick=function(){on=!on;b.textContent=on?'\uD83D\uDD0A':'\uD83D\uDD07';if(on)blip(880,1320,.09,.05)};
document.body.appendChild(b)}catch{}
})();
</script>
<script>
/* nano-guard-v2: (1) matikan menu tekan-lama/seleksi/seret, (2) geser di area permainan
   tidak menutup webview, (3) tombol balas SEKETIKA saat jari menyentuh supaya ambang
   tekan-lama WhatsApp tidak pernah tercapai (klik asli sesudahnya dimatikan). */
(function(){var D=document,i,evs=['contextmenu','selectstart','dragstart','gesturestart'];
for(i=0;i<evs.length;i++)D.addEventListener(evs[i],function(e){var t=e.target;if(t&&t.closest&&t.closest('textarea,input,[contenteditable]'))return;e.preventDefault()},false);
D.addEventListener('touchmove',function(e){var t=e.target,n;if(t&&t.closest&&t.closest('textarea,input,[contenteditable],.ovCard,.modal'))return;
for(n=t;n&&n!==D.body;n=n.parentElement)if(n.scrollHeight>n.clientHeight+4)return;
if(D.documentElement.scrollHeight>window.innerHeight+4)return;e.preventDefault()},{passive:false});
var sup=false,syn=false,PAD=/(btn|button|key|pad|tab|chip|cell|tile|card|lvt|opt|choice|pick|cmd|ctl|num|digit)/i;
function hit(el){for(var n=el,k=0;n&&n!==D.body&&k<5;n=n.parentElement,k++){var tn=n.tagName;
if(tn==='BUTTON'||tn==='A'||tn==='SUMMARY')return true;
if(n.getAttribute&&n.getAttribute('role')==='button')return true;
if(n.className&&typeof n.className==='string'&&PAD.test(n.className))return true}return false}
/* Satu ketukan = satu aksi: klik buatan kita dibedakan dari klik asli lewat isTrusted,
   jadi urutan keduanya tidak lagi bisa membuat aksi jalan dua kali. */
var g=null;
D.addEventListener('pointerdown',function(e){if(e.button)return;var t=e.target;
if(!t||!t.dispatchEvent||!hit(t))return;
if(t.closest&&t.closest('textarea,input,select,[contenteditable]'))return;
var x=e.clientX,y=e.clientY,gg={done:0};g=gg;
setTimeout(function(){
if(gg.done)return;gg.done=1;if(e.defaultPrevented)return;syn=true;
try{t.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,clientX:x,clientY:y,button:0}))}catch(err){}
syn=false;setTimeout(function(){if(g===gg)g=null},700)},0)},true);
D.addEventListener('click',function(e){
if(syn||!g)return;var gg=g;g=null;
if(!gg.done){gg.done=1;return}
if(e.isTrusted){e.stopPropagation();e.preventDefault()}},true)})();
</script>
<style>
html,body{overscroll-behavior:none;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}
img,canvas,svg{-webkit-user-drag:none;-webkit-touch-callout:none}
textarea,input,select,[contenteditable]{-webkit-user-select:text;user-select:text}
button,[role="button"],a,.btn,.key,.pad,.tab,.lvt,.chip,.cell,.tile,.card{-webkit-user-select:none;user-select:none;touch-action:manipulation}
canvas{touch-action:none}
</style>
<!-- nano-polish -->
<style>
/* lapisan kilap aditif: tidak mengubah tata letak, hanya rasa sentuh & ketajaman */
*{-webkit-tap-highlight-color:transparent;text-rendering:optimizeLegibility}
button,[role="button"],.btn,.key,.pad,a{-webkit-user-select:none;user-select:none;transition:transform .07s ease,filter .16s ease,box-shadow .22s ease}
button:active,[role="button"]:active,.btn:active,.key:active,.pad:active{transform:translateY(1px) scale(.985);filter:brightness(1.07)}
canvas,svg,img{-webkit-user-drag:none;user-select:none}
::selection{background:rgba(212,180,143,.35)}
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-thumb{background:rgba(212,180,143,.35);border-radius:99px}
::-webkit-scrollbar-track{background:transparent}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation-duration:.001ms!important}}
/* ── lapisan HD Nano ─────────────────────────────
   cahaya ruang dari kiri-atas + vignette + butiran halus supaya layar
   tidak terasa datar. Tidak mengubah tata letak sama sekali. */
html{-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;text-rendering:optimizeLegibility}
canvas,img,svg{-webkit-user-drag:none;-webkit-user-select:none;user-select:none}
html::after{content:"";position:fixed;inset:0;z-index:9;pointer-events:none;background-image:radial-gradient(122% 82% at 16% -12%,rgba(255,255,255,.11),rgba(255,255,255,0) 58%),radial-gradient(132% 112% at 92% 118%,rgba(0,0,0,.20),rgba(0,0,0,0) 62%),url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23n)' opacity='.06'/%3E%3C/svg%3E");background-size:auto,auto,160px 160px}
/* ── material v2: bevel + bayangan kontak supaya elemen terasa benda nyata ── */
.btn,.key,.chip,.chipBtn,.mini,.tab,.pad button{box-shadow:inset 0 1px 0 rgba(255,255,255,.16),inset 0 -2px 0 rgba(0,0,0,.42),0 7px 16px rgba(0,0,0,.45)}
.cell,.tile,.block,.pod{box-shadow:inset 0 1px 0 rgba(255,255,255,.24),inset 0 -2px 0 rgba(0,0,0,.3),0 3px 8px rgba(0,0,0,.42)}
.panel,.card,.stat,.stats,.modal,.grid,.board{box-shadow:inset 0 1px 0 rgba(255,255,255,.1),0 16px 36px rgba(0,0,0,.5),0 2px 0 rgba(0,0,0,.45)}
div:has(>canvas){position:relative;border-radius:12px;box-shadow:0 18px 40px rgba(0,0,0,.55),inset 0 0 0 1px rgba(255,255,255,.08)}
div:has(>canvas)>canvas{border-radius:10px;display:block}

/* ── material v3: kedalaman benda nyata: bevel, kilau, bayangan kontak ── */
/* gloss + kontak umum: dipakai kalau game tidak punya aturan khusus */
.btn,.chip,.chipBtn,.key,.mini,.tab{border-radius:11px!important;box-shadow:inset 0 2px 0 rgba(255,255,255,.22),inset 0 -3px 5px rgba(0,0,0,.42),0 4px 0 rgba(0,0,0,.42),0 8px 16px rgba(0,0,0,.4)!important}
.panel{border-radius:16px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.12),inset 0 -4px 12px rgba(0,0,0,.42),0 16px 36px rgba(0,0,0,.5),0 2px 0 rgba(0,0,0,.45)!important}
.gameLayout,.cluePanel{border-radius:14px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.18),inset 0 -4px 12px rgba(0,0,0,.38),0 14px 34px rgba(0,0,0,.45)!important}
.cell{border-radius:4px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.35),inset 0 -2px 3px rgba(0,0,0,.18),0 2px 5px rgba(0,0,0,.3)!important}
.stats,.tools{border-radius:11px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.18),0 5px 14px rgba(0,0,0,.4)!important}
</style>
</body>
</html>`

const handler = async (m, { conn }) => {
  if (!m?.chat || !conn) return

  const reactionKey = m?.raw?.key || m?.key
  if (reactionKey) await conn.sendMessage(m.chat, { react: { text: '🧩', key: reactionKey } }).catch(() => {})

  await conn.relayMessage(
    m.chat,
    {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {},
      },
      botForwardedMessage: {
        message: {
          richResponseMessage: {
            messageType: 1,
            submessages: [
              {
                messageType: 2,
                messageText: 'Nano Ai TTS • Crossword 🧩',
              },
            ],
            unifiedResponse: {
              data: Buffer.from(
                JSON.stringify({
                  response_id: 'nano-ai-tts-2026',
                  sections: [
                    {
                      view_model: {
                        primitive: {
                          __typename: 'GenAIaeacdsnwHtmlPrimitive',
                          payload: html,
                          trusted_sources: [],
                        },
                        __typename: 'GenAISingleLayoutViewModel',
                      },
                    },
                  ],
                })
              ).toString('base64'),
            },
            contextInfo: {
              forwardingScore: 1,
              isForwarded: true,
              forwardedAiBotMessageInfo: {
                botJid: '867051314767696@bot',
              },
              forwardOrigin: 4,
            },
          },
        },
      },
    },
    {}
  )
}

handler.help = ['tts', 'teka', 'teki', 'silang']
handler.tags = ['game']
handler.command = /^(tts|teka|teki|silang)$/i
handler.category = 'game'
handler.groupOnly = false
handler.limit = false
handler.description = 'Game Teka Teki Silang Nano Ai dengan puzzle dinamis, skor, petunjuk dan statistik'

export default handler
