/*
⌬
┇ ━━━[ 🥳 𝗪𝗘𝗟𝗖𝗢𝗠𝗘 𝗕𝗥𝗢𝗞 ]━━━━
┇
┇ ❘█▀█ █ █▀█ █▀█   ▄▀█ █
┇ █  █ █ █▀▄ █▄█   █▀█ █    
┇  ▀█  --N--a--n--o------A--i-----
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ 💬 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 ]━━━━
┇
┇▫️Author  : Danz nano & Awang Ofc 
┇▫️Website  : awangofc.my.id
┇▫️WhatsApp : wa.me/556184127506
┇
┇ ▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬▭
┇
┇ ━━━[ ✍️ 𝗖𝗔𝗧𝗔𝗧𝗔𝗡 ]━━━━
┇
┇🔸Dilarang Menghapus Creadit SC
┇🔸Dilarang Menjual Script Nano Ai
┇🔸Dilarang Mengatas Namakan Script!!
⌬
*/

import { getUser } from '../../lib/rpg/database.js'
import { buildRpgContext } from '../../lib/rpg/context.js'
import { CATEGORIES, getItemInfo } from '../../lib/rpg/items.js'
import { sendRpgCard } from '../../lib/rpg/ui.js'

const handler = async (rawM, tools) => {
  const { m, sock } = buildRpgContext(rawM, tools)
  const user = getUser(m.sender)

  const items = []
  for (const categoryItems of Object.values(CATEGORIES)) {
    for (const [key, info] of Object.entries(categoryItems)) {
      const count = user.inventory[key] || 0
      if (count > 0) items.push({ name: info.name.replace(/^[^\p{L}\p{N}]+/u, ''), count })
    }
  }

  const knownItems = new Set(Object.values(CATEGORIES).flatMap((category) => Object.keys(category)))
  for (const [key, count] of Object.entries(user.inventory)) {
    if (count > 0 && !knownItems.has(key)) {
      const info = getItemInfo(key)
      items.push({ name: info.name.replace(/^[^\p{L}\p{N}]+/u, ''), count })
    }
  }

  const visibleItems = items.slice(0, 12)
  const body = items.length
    ? `${items.length > visibleItems.length ? `${items.length - visibleItems.length} item lainnya tidak ditampilkan di kartu.\n` : ''}Gunakan ${m.prefix}use <item> untuk memakai barang.`
    : 'Tas masih kosong. Coba mainkan fitur RPG lain untuk mendapatkan item.'

  return sendRpgCard(sock, m, {
    type: 'inventory',
    headerTitle: 'INVENTORY',
    headerSubtitle: `${items.length} item tersimpan`,
    data: {
      title: m.pushName || 'Player',
      name: m.pushName || 'Player',
      koin: user.koin,
      health: user.rpg.health,
      maxHealth: user.rpg.maxHealth,
      items: visibleItems,
    },
    body,
  })
}

handler.command = /^(inventory|inv|tas|bag)$/i
handler.help = ['inventory', 'inv', 'tas', 'bag']
handler.tags = ['rpg']
handler.category = 'rpg'
handler.groupOnly = true
handler.description = 'Melihat isi inventory RPG'

export default handler
